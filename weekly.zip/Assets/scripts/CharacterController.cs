using System.Collections;
using System.Collections.Generic;
using UnityEditor.ShaderGraph.Internal;
using UnityEngine;

public class CharacterController : MonoBehaviour
{
    public float movementSpeed = 5f;
    public float jumpheight = 200;
    void Update()
    {
        // transform.position++; doesnt work
        // Vector3 moveFoward = Vector3.forward; - correct
        // transform.position = transform.position + moveFoward; - correct
        // or transform.position += moveDirection

        float horizontalInput = Input.GetAxis("Horizontal");
        Vector3 hMovement = transform.right * horizontalInput * movementSpeed * Time.deltaTime;

        float verticalInput = Input.GetAxis("Vertical");
        Vector3 vMovement = transform.forward * verticalInput * movementSpeed * Time.deltaTime;

        transform.position += vMovement;
        transform.position += hMovement;

        if (Input.GetKey(KeyCode.Space))
        {
            transform.position += (Vector3.up * jumpheight) * Time.deltaTime;
        }

    }
}
// or you can be cooler
